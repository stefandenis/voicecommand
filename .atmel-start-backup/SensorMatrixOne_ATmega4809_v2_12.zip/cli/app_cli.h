/*
 * cli.h
 *
 * Created: 4/16/2018 6:07:59 PM
 *  Author: M17336
 */ 


#ifndef CLI_H_
#define CLI_H_

void cli_command_receiver(void);

#endif /* CLI_H_ */