/*
 * cli.c
 *
 * Created: 4/16/2018 6:09:11 PM
 *  Author: M17336
 */ 
#include <stdlib.h>
#include <stdint.h>
#include "app_cli.h"
#include "app_state_machine/state_machine.h"
#include "config.h"
#include "usart_basic.h"

char command[30];
uint8_t i = 0;

char command_reconnect[] = "reconnect";
char command_wifi_auth[] = "wifi";
char command_key[] = "key";
char command_project[] = "project";
char command_region[] = "region";
char command_registry[] = "registry";
char command_device[] = "device";

void unknown_command(void);
void reconnect_cmd(void);
void set_wifi_auth(char *ssid_pwd_auth);
void set_project_id(char *project_id);
void set_project_region(char *region);
void set_registry_id(char *registry_id);
void set_device_id(char *device_id);
void get_public_key(void);
void get_project_id(void);
void get_region(void);
void get_registry(void);
void get_device_id(void);

struct cmd {
	char *command;
	void (*handler_without_argument)(void);	
	void (*handler_with_argument)(char *argument);
};

struct cmd commands[7] = {
	{ command_reconnect, reconnect_cmd,        NULL },
	{ command_wifi_auth, NULL,           set_wifi_auth },
	{ command_key,       get_public_key, NULL },
	{ command_project,   get_project_id, set_project_id },
	{ command_region,    get_region,     set_project_region },
	{ command_registry,  get_registry,   set_registry_id },
	{ command_device,    get_device_id,  set_device_id },
};

void cli_command_receiver() {
	if(USART_0_is_rx_ready()) {
		char c = USART_0_read();
		printf("%c", c);
		if( c != '\n' && c != 0 && c!='\r' ){
			command[i++] = c;
			} else if(c == '\n') {
			command[i] = '\0';
			command_received(command);
			i = 0;
		}
	}
}

void cli_out(const char msg[]) {
	printf("%s\n\r", msg);
}

// TODO: lower case; leave only device, key and wifi commands
void unknown_command() {
	cli_out("Unknown command. Available commands are:\n\r"
			"reconnect - reconnect to cloud service\n\r"
			"key - get public key\n\r"
			"device - get device name\n\r"
			"device <id> - set device name\n\r"
			"project - get project name\n\r"
			"project <id> - set project name\n\r"
			"region - get project region\n\r"
			"region <region> - sets project region\n\r"
			"registry - get registry name\n\r"
			"registry <id> - set registry name\n\r"
			"wifi <ssid>,<password>,<auth type> - set Wi-Fi SSID, password and authentication type");
}

void reconnect_cmd(void) {
	cli_out("Board will restart...");
	app_state_machine_init();
}

void set_wifi_auth(char *ssid_pwd_auth) {
	char *credentials[4];
	uint8_t i = 0;
	
	char * pch;
	pch = strtok (ssid_pwd_auth, ",");
	while (pch != NULL && i < 4)
	{
		credentials[i++] = pch;
		pch = strtok (NULL, ",");
	}
	
	if(i != 3) {
		unknown_command();
	} else {
		if(strlen(credentials[0]) < MAX_WIFI_CREDENTIALS_LENGTH) {
			strcpy(ssid, credentials[0]);
		}
		if(strlen(credentials[1]) < MAX_WIFI_CREDENTIALS_LENGTH) {
			strcpy(pass, credentials[1]);
		}
		if(strlen(credentials[2]) < MAX_WIFI_CREDENTIALS_LENGTH) {
			auth_type = atoi(credentials[2]);
		}
		cli_out("OK");
	}
}

void set_project_id(char *new_project_id) {
	if(strlen(new_project_id) < MAX_PROJECT_METADATA_LENGTH) {
		strcpy(project_id, new_project_id);
		cli_out("OK");		
	} else {
		cli_out("Project ID cannot be that long.");
	}

}

void set_project_region(char *new_project_region) {
	if(strlen(new_project_region) < MAX_PROJECT_METADATA_LENGTH) {
		strcpy(project_region, new_project_region);
		cli_out("OK");
	} else {
		cli_out("Project region cannot be that long.");
	}
	
}

void set_registry_id(char *new_registry_id) {
	if(strlen(new_registry_id) < MAX_PROJECT_METADATA_LENGTH) {
		strcpy(registry_id, new_registry_id);
		cli_out("OK");
	} else {
		cli_out("Registry ID cannot be that long.");
	}
}

void set_device_id(char *new_device_id) {
	if(strlen(new_device_id) < MAX_PROJECT_METADATA_LENGTH) {
		strcpy(device_id, new_device_id);
		cli_out("OK");
	} else {
		cli_out("Device ID cannot be that long.");
	}
}

void get_public_key(void) {
	uint8_t buf[128];
	config_build_public_key(buf);
	// Key format includes "begin" and "end" delimiter strings
	cli_out("-----BEGIN PUBLIC KEY-----");
	cli_out(buf);
	cli_out("-----END PUBLIC KEY-----");
}

void get_project_id(void) {
	cli_out(project_id);
}

void get_region(void) {
	cli_out(project_region);
}

void get_registry(void) {
	cli_out(registry_id);
}

void get_device_id(void) {
	cli_out(device_id);
}

uint8_t startsWith(const char *with, const char *str) {
	uint8_t with_len = strlen(with);
	uint8_t str_len = strlen(str);
	return str_len < with_len ? 0 : strncmp(with, str, with_len) == 0;
}

void command_received(char *command_text) {
	char *argument = strstr(command_text, " ");
	
	if(argument != NULL) {
		*argument = '\0';
	}
	
	for(uint8_t i = 0; i < 7; i++) {
		uint8_t cmp = strcmp(command_text, commands[i].command);
		uint8_t ct_len = strlen(command_text);		
		uint8_t cc_len = strlen(commands[i].command);
		
		if(cmp == 0 && ct_len == cc_len) {
			if(argument == NULL) {
				if(commands[i].handler_without_argument != NULL) {
					commands[i].handler_without_argument();
					return;
				}
			} else {  
				argument++;
				if(commands[i].handler_with_argument != NULL) {
					commands[i].handler_with_argument(argument);
					return;
				}
			}
		}
	}
	
	unknown_command();
}
