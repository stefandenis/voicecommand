/*
 * network_handlers.h
 *
 * Created: 4/24/2018 2:52:48 PM
 *  Author: M17336
 */ 


#ifndef NETWORK_HANDLERS_H_
#define NETWORK_HANDLERS_H_

#include <stdint.h>
#include "socket/include/socket.h"

void wifi_cb(uint8_t u8MsgType, void *pvMsg);
void m2m_tcp_socket_handler(SOCKET sock, uint8_t u8Msg, void *pvMsg);


#endif /* NETWORK_HANDLERS_H_ */