/*
 * network_handlers.c
 *
 * Created: 4/24/2018 2:53:27 PM
 *  Author: M17336
 */ 

#include "mqtt_client/umqtt_client.h"
#include "network_handlers.h"
#include "app_state_machine/state_machine.h"
#define MAIN_WIFI_M2M_BUFFER_SIZE		48

uint8_t gau8SocketBuffer[MAIN_WIFI_M2M_BUFFER_SIZE];

void m2m_tcp_socket_handler(SOCKET sock, uint8_t u8Msg, void *pvMsg)
{
	int16_t ret;
	
	switch (u8Msg) {
	case SOCKET_MSG_BIND:
	{
		tstrSocketBindMsg *pstrBind = (tstrSocketBindMsg *)pvMsg;
		if (pstrBind && pstrBind->status == 0) {
			ret = recvfrom(sock, gau8SocketBuffer, MAIN_WIFI_M2M_BUFFER_SIZE, 0);
			if (ret != SOCK_ERR_NO_ERROR) {
				bind_ntp_socket_state.status = FAILED;
			} else {
				bind_ntp_socket_state.status = COMPLETED;
			}
		} else {
			bind_ntp_socket_state.status = FAILED;
		}

		break;
	}
	
	case SOCKET_MSG_RECVFROM:
	{
		/* printf("socket_cb: socket_msg_recvfrom!\r\n"); */
		tstrSocketRecvMsg *pstrRx = (tstrSocketRecvMsg *)pvMsg;
		if (pstrRx->pu8Buffer && pstrRx->s16BufferSize) {
			
			uint8_t packetBuffer[48];
			memcpy(packetBuffer, pstrRx->pu8Buffer, sizeof(packetBuffer));

			if ((packetBuffer[0] & 0x7) != 4) {                   /* expect only server response */
				//printf("socket_cb: Expecting response from Server Only!\r\n");
				return;                    /* MODE is not server, abort */
			} else {
				uint32_t secsSince1900 = 0;
				secsSince1900 = (uint32_t)((uint32_t)packetBuffer[40] << 24) | (uint32_t)((uint32_t)packetBuffer[41] << 16) | (uint32_t)((uint32_t)packetBuffer[42] << 8) | (uint32_t)((uint32_t)packetBuffer[43]);
			
				/* Now convert NTP time into everyday time.
				 * Unix time starts on Jan 1 1970. In seconds, that's 2208988800.
				 * Subtract seventy years.
				 */
				epoch = (secsSince1900 - 2208988800UL);
				ntp_req_state.status = COMPLETED;
					
				ret = close(sock);
				if (ret == SOCK_ERR_NO_ERROR) {
					udp_socket = -1;
				}
			}
		}
	}
	break;
	
	/* Socket connected */
	case SOCKET_MSG_CONNECT:
	{
		tstrSocketConnectMsg *pstrConnect = (tstrSocketConnectMsg *)pvMsg;
		if (pstrConnect && pstrConnect->s8Error >= 0) {
			tls_connect_state.status = COMPLETED;
		} else {
			tls_connect_state.status = FAILED;
		}
	}
	break;

	case SOCKET_MSG_SEND:
	{
		recv(tcp_client_socket, gau8SocketBuffer, sizeof(gau8SocketBuffer), 0);
	}
	break;

	/* Message receive */
	case SOCKET_MSG_RECV:
	{
		tstrSocketRecvMsg *pstrRecv = (tstrSocketRecvMsg *)pvMsg;
			if (pstrRecv && pstrRecv->s16BufferSize > 0) {
				mqtt_receive(pstrRecv->pu8Buffer, pstrRecv->s16BufferSize);
			} else {
				consume_connection_state.status = COMPLETED;
				mqtt_connect_state.status = FAILED;
		}
	} 
	break;
	
	default:
		break;
	}
}

void wifi_cb(uint8_t u8MsgType, void *pvMsg) {
	switch (u8MsgType) {
		case M2M_WIFI_REQ_DHCP_CONF:
			init_phy_state.status = COMPLETED;
			break;

		default:
			break;
	}
}
