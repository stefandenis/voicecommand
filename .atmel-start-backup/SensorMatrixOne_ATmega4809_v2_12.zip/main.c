#include "main.h"
#include <atmel_start.h>
#include <atomic.h>
#include "mqtt_client/umqtt_client.h"
#include "cli/cli_io.h"
#include "app_state_machine/state_machine.h"

absolutetime_t sendToGoogle(void)
{
	if(is_mqtt_connected()) 
	{
		LED0_toggle_level();
		adc_result_t ADC_0_measurement = ADC_0_get_conversion(6);
		mqtt_publish(mqtt_topic, &ADC_0_measurement, sizeof(ADC_0_measurement));
	}
	return SEND_INTERVAL;
}

int main(void)
{	
	ENABLE_INTERRUPTS();
	atmel_start_init();
	app_state_machine_init();
	
	while (1) {
		cli_command_receiver();
		m2m_wifi_handle_events(NULL);
		state_machine_driver();
	}
	
	return 0;
}