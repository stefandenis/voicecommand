/*
 * umqtt_client.c
 *
 * Created: 4/25/2018 11:45:45 AM
 *  Author: M17336
 */ 
#include "app_state_machine/state_machine.h"
#define TX_BUFF_SIZE 400
#define RX_BUFF_SIZE 100
#define PASSWORD_SPACE 264
#define USER_LENGTH 0
#define PASSWORD_SIZE 202
#define MQTT_KEEP_ALIVE_TIME 120

static uint8_t mqtt_txbuff[TX_BUFF_SIZE];
static uint8_t mqtt_rxbuff[RX_BUFF_SIZE];
uint8_t mqtt_password[PASSWORD_SPACE];

static void umqtt_connected_cb (struct umqtt_connection * conn)
{
	mqtt_connect_state.status = COMPLETED;
}

static void umqtt_send_packet (struct umqtt_connection *conn)
{
	send(tcp_client_socket, conn->txbuff.start, conn->txbuff.datalen, 0);
	umqtt_circ_init(&conn->txbuff);
}

struct umqtt_connection umqtt_conn = {
	.txbuff = {
		.start = mqtt_txbuff,
		.length = TX_BUFF_SIZE,
	},
	.rxbuff = {
		.start = mqtt_rxbuff,
		.length = RX_BUFF_SIZE,
	},
	
	.user = NULL,
	.user_len = USER_LENGTH,
	.password = mqtt_password,
	.password_len = PASSWORD_SIZE,
	
	.clientid = cid,
	.kalive = MQTT_KEEP_ALIVE_TIME,
	
	.connected_callback = umqtt_connected_cb,
	.new_packet_callback = umqtt_send_packet
};

void mqtt_publish(char *topic, uint8_t *data, uint8_t datalen) {
	umqtt_publish(&umqtt_conn, topic, data, datalen);
}

void mqtt_receive(uint8_t *data, uint8_t len) {
	umqtt_circ_push(&umqtt_conn.rxbuff, data, len);
	umqtt_process(&umqtt_conn);
}

void mqtt_connect(void) {
	umqtt_circ_init(&umqtt_conn.txbuff);
	umqtt_circ_init(&umqtt_conn.rxbuff);
	umqtt_connect(&umqtt_conn);
}

bool is_mqtt_connected(void) {
	return umqtt_conn.state == UMQTT_STATE_CONNECTED;
}