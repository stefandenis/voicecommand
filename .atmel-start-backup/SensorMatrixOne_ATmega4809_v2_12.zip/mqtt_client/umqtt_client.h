/*
 * umqtt_client.h
 *
 * Created: 4/25/2018 11:45:34 AM
 *  Author: M17336
 */ 


#ifndef UMQTT_CLIENT_H_
#define UMQTT_CLIENT_H_

#include <stdbool.h>
#include "umqtt/umqtt.h"

extern uint8_t mqtt_password[264];

void mqtt_publish(char *topic, uint8_t *data, uint8_t datalen);
void mqtt_receive(uint8_t *data, uint8_t len);
void mqtt_connect(void);
bool is_mqtt_connected(void);

#endif /* UMQTT_CLIENT_H_ */