/*
 * ap_mode.c
 *
 * Created: 4/27/2018 6:47:50 PM
 *  Author: M17336
 */ 

#include "state_machine.h"

#define MAIN_WLAN_SSID "WINC1500_AP" /* < SSID */
#define MAIN_WLAN_AUTH M2M_WIFI_SEC_WPA_PSK /* < Security manner */
#define MAIN_WLAN_WPA_PSK "1234567890" /* < Security Key in WPA PSK Mode */
#define MAIN_WLAN_CHANNEL (M2M_WIFI_CH_6) /* < Channel number */

error_t start_ap(void);

state_t ap_state = {
	.state_func = start_ap,
	.timeout = NO_TIMEOUT,
	.status = EXECUTE
};

error_t start_ap(void) {
	/* Initialize AP mode parameters structure with SSID, channel and OPEN security
	type. */
	tstrM2MAPConfig strM2MAPConfig;
	
	memset(&strM2MAPConfig, 0x00, sizeof(tstrM2MAPConfig));
	strcpy((char *)&strM2MAPConfig.au8SSID, MAIN_WLAN_SSID);
	
	strM2MAPConfig.u8ListenChannel = MAIN_WLAN_CHANNEL;
	strM2MAPConfig.u8SecType = MAIN_WLAN_AUTH;
	strM2MAPConfig.au8DHCPServerIP[0] = 192;
	strM2MAPConfig.au8DHCPServerIP[1] = 168;
	strM2MAPConfig.au8DHCPServerIP[2] = 1;
	strM2MAPConfig.au8DHCPServerIP[3] = 1;

	strcpy((char *)&strM2MAPConfig.au8Key, MAIN_WLAN_WPA_PSK);
	strM2MAPConfig.u8KeySz = strlen(MAIN_WLAN_WPA_PSK);

	/* Bring up AP mode with parameters structure. */
	if (M2M_SUCCESS != m2m_wifi_enable_ap(&strM2MAPConfig)) {
		return AP_ENABLE_ERROR;
	}
	
	return NO_ERROR;
}