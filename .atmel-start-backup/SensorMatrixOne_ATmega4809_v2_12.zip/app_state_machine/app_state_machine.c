/*
 * app_state_machine.c
 *
 * Created: 4/19/2018 12:09:30 PM
 *  Author: M17336
 */ 
#include "main.h"
#include "timeout.h"
#include "state_machine.h"
#include "network_handlers/network_handlers.h"
#include "mqtt_client/umqtt_client.h"

#define MQTT_CID_LENGTH 100
#define MQTT_TOPIC_LENGTH 30

SOCKET tcp_client_socket = -1;
SOCKET udp_socket = -1;

uint32_t epoch = 0;

char cid[MQTT_CID_LENGTH];
char mqtt_topic[MQTT_TOPIC_LENGTH];

char ssid[] = "zambiluta";
char pass[] = "microchip";
int auth_type = 2;
char project_id[] = "mchpiot-184909";
char project_region[] = "asia-east1";
char registry_id[] = "my-registry";
char device_id[] = "device-1";

error_t init_phy(void);
error_t bind_ntp_socket(void);
error_t ntp_req(void);
error_t password_generate(void);
error_t tls_connect();
error_t cloud_connect(void);
error_t set_up_send_timer(void);
error_t reconnect(void);

state_t init_phy_state = {
	.state_func = &init_phy,
	.nextState = &bind_ntp_socket_state,
	.status = EXECUTE,
	.timeout = 5000,
	.onFailError = WIFI_CONNECT_ERROR	
};

state_t bind_ntp_socket_state = {
	.state_func = bind_ntp_socket,
	.nextState = &ntp_req_state,
	.status = EXECUTE,
	.timeout = 5000,
	.onFailError = BIND_ERROR
};

state_t ntp_req_state = {
	.state_func = ntp_req,
	.nextState = &tls_connect_state,
	.status = EXECUTE,
	.timeout = 5000,
	.onFailError = NO_NTP_RES_ERROR
};

state_t tls_connect_state = {
	.state_func = tls_connect,
	.nextState = &mqtt_connect_state,
	.status = EXECUTE,
	.timeout = 5000,
	.onFailError = TLS_ERROR
};

state_t mqtt_connect_state = {
	.state_func = cloud_connect,
	.nextState = &consume_connection_state,
	.status = EXECUTE,
	.timeout = 5000,
	.onFailError = MQTT_CONNECT_ERROR
};

state_t consume_connection_state = {
	.state_func = set_up_send_timer,
	.nextState = &reconnect_state,
	.status = EXECUTE,
	.timeout = NO_TIMEOUT,
	.onFailError =	TRANSMIT_ERROR
};

state_t reconnect_state = {
	.state_func = reconnect,
	.nextState = &bind_ntp_socket_state,
	.status = EXECUTE,
	.timeout = NO_TIMEOUT,
	.onFailError = NO_ERROR
};

static timer_struct_t sendToGoogle_timer;

error_t init_phy(void) {
	tstrWifiInitParam param;
	
	/* Initialize the BSP. */
	nm_bsp_init();
	
	/* Callback for wifi */
	param.pfAppWifiCb = wifi_cb;
	
	/* Initialize WINC1500 Wi-Fi driver with data and status callbacks. */
	if (M2M_SUCCESS != m2m_wifi_init(&param)) {
		return WIFI_INIT_ERROR;
	}

	/* Connect to router. */
	if(M2M_SUCCESS != m2m_wifi_connect((char *)ssid, sizeof(ssid), auth_type, (char *)pass, M2M_WIFI_CH_ALL)) {
		return WIFI_CONNECT_ERROR;
	}
	
	return NO_ERROR;
}

error_t bind_ntp_socket(void) {
	socketInit();
	registerSocketCallback(m2m_tcp_socket_handler, NULL);
	
	struct sockaddr_in addr_in;
	// Get NPT
	udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if (udp_socket < 0) {
		return UDP_SOCKET_ERROR;
	}

	/* Initialize default socket address structure. */
	addr_in.sin_family = AF_INET;
	addr_in.sin_addr.s_addr = _htonl(0xffffffff);
	addr_in.sin_port = _htons(6666);

	bind(udp_socket, (struct sockaddr *)&addr_in, sizeof(struct sockaddr_in));

	return NO_ERROR;
}

error_t ntp_req(void) {
	struct sockaddr_in addr;
	int8_t cDataBuf[48];
	int16_t ret;

	memset(cDataBuf, 0, sizeof(cDataBuf));
	cDataBuf[0] = 0x1B; /* time query */
	
	addr.sin_family = AF_INET;
	addr.sin_port = _htons(123);
	addr.sin_addr.s_addr = _htonl(0xD8EF2308); // 0xD8EF2308 time.google.com; 0xC0A80037 - alex pc on zambiluta network

	/*Send an NTP time query to the NTP server*/
	ret = sendto(udp_socket, (int8_t *)&cDataBuf, sizeof(cDataBuf), 0, (struct sockaddr *)&addr, sizeof(addr));
	
	return NO_ERROR;
}

error_t tls_connect(void) {
	struct sockaddr_in addr;

	if ((tcp_client_socket = socket(AF_INET, SOCK_STREAM, 1)) < 0) {
		return TCP_SOCKET_ERROR;
	}

	addr.sin_family = AF_INET;
	addr.sin_port = _htons(8883);
	addr.sin_addr.s_addr = _htonl(0x40E9B8CE); // 0x40E9B8CE - mqtt.googleapis.com, 0xC0A80036 - 0.54, 0xC0A80037 - 0.55
	
	/* Connect server */
	sint8 ret = connect(tcp_client_socket, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

	if (ret < 0) {
		close(tcp_client_socket);
		tcp_client_socket = -1;
		return TCP_CONNECT_ERROR;
	}
	
	return NO_ERROR;
}

error_t cloud_connect(void) {
	config_get_client_password(mqtt_password, 264, (uint32_t)epoch);
	
	sprintf(cid, "projects/%s/locations/%s/registries/%s/devices/%s", project_id, project_region, registry_id, device_id);
	sprintf(mqtt_topic, "/devices/%s/events", device_id);
	
	mqtt_connect();
	
	return NO_ERROR;
}

error_t set_up_send_timer(void) {
	sendToGoogle_timer.callback_ptr = sendToGoogle;
	Scheduler_timeout_create(&sendToGoogle_timer, 1);
	return NO_ERROR;
}

error_t reconnect(void) {
	Scheduler_timeout_delete(&sendToGoogle_timer);
	close(tcp_client_socket);
	tcp_client_socket = -1;
	return NO_ERROR;
}