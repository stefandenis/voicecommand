/*
 * app_state_machine.h
 *
 * Created: 4/19/2018 12:09:12 PM
 *  Author: M17336
 */ 


#ifndef APP_STATE_MACHINE_H_
#define APP_STATE_MACHINE_H_

#include "umqtt/umqtt.h"
#include "timeout.h"
#include "socket/include/socket.h"

#define NO_TIMEOUT 0xFFFFFFFF
#define INSTANT_TIMEOUT 0
#define MAX_PROJECT_METADATA_LENGTH 15
#define MAX_WIFI_CREDENTIALS_LENGTH 15

typedef enum {
	NO_ERROR,
	WIFI_INIT_ERROR,
	WIFI_CONNECT_ERROR,
	UDP_SOCKET_ERROR,
	BIND_ERROR,
	NO_NTP_RES_ERROR,
	TCP_SOCKET_ERROR,
	TCP_CONNECT_ERROR,
	TLS_ERROR,
	MQTT_CONNECT_ERROR,
	BACK_OFF_FATAL_ERROR,
	TRANSMIT_ERROR,
	AP_ENABLE_ERROR
} error_t;

typedef enum {
	EXECUTE,
	PENDING,
	COMPLETED,
	FAILED
} state_status_t;

typedef struct state {
	struct state * nextState;
	error_t (*state_func)(void);
	state_status_t status;
	absolutetime_t timeout;
	error_t onFailError;
} state_t;

extern SOCKET tcp_client_socket;
extern SOCKET udp_socket;

extern uint32_t epoch;

extern char cid[100];
extern char mqtt_topic[30];

extern char ssid[MAX_WIFI_CREDENTIALS_LENGTH];
extern char pass[MAX_WIFI_CREDENTIALS_LENGTH];
extern int auth_type;

extern char project_id[MAX_PROJECT_METADATA_LENGTH];
extern char project_region[MAX_PROJECT_METADATA_LENGTH];
extern char registry_id[MAX_PROJECT_METADATA_LENGTH];
extern char device_id[MAX_PROJECT_METADATA_LENGTH];

extern state_t init_phy_state, bind_ntp_socket_state, ntp_req_state, tls_connect_state, mqtt_connect_state, consume_connection_state, reconnect_state, ap_state;

void app_state_machine_init(void);
void state_machine_driver(void);

#endif /* APP_STATE_MACHINE_H_ */