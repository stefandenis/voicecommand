/*
 * core_state_machine.c
 *
 * Created: 4/25/2018 6:34:49 PM
 *  Author: M17336
 */ 

#include "state_machine.h"

static state_t *current_state;
static timer_struct_t wait_timer;

static absolutetime_t wait_timer_cb(void) {
	current_state->status = FAILED;
	return 0;
}

void app_state_machine_init(void) {
	current_state = &init_phy_state;
	current_state->status = EXECUTE;
}

void state_machine_driver(void) {
	error_t err;
	
	switch(current_state->status) {
		case EXECUTE:
			err = current_state->state_func();
			if(err != NO_ERROR) {
				error_handler(err);
			} else {
				switch(current_state->timeout) {
					case NO_TIMEOUT:
						current_state->status = PENDING;
						break;
					case INSTANT_TIMEOUT:
						current_state->status = COMPLETED;
						break;
					default:
						current_state->status = PENDING;
						wait_timer.callback_ptr = wait_timer_cb;
						Scheduler_timeout_create(&wait_timer, current_state->timeout);
						break;
				}
			}
		break;
		
		case PENDING:
			Scheduler_timeout_call_next_callback();
			break;
		
		case COMPLETED:
			current_state = current_state->nextState;
			current_state->status = EXECUTE;
			Scheduler_timeout_delete(&wait_timer);
			break;
		
		case FAILED:
			error_handler(current_state->onFailError);
			break;
		
		default:
			break;
	}
}

void error_handler(error_t err) {
	switch(err) {
		case TRANSMIT_ERROR:
			current_state = current_state->nextState;
			current_state->status = EXECUTE;
			break;
		case TLS_ERROR:
		case MQTT_CONNECT_ERROR:
		case WIFI_INIT_ERROR:
		case WIFI_CONNECT_ERROR:
			current_state = &ap_state;
			current_state->status = EXECUTE;
			break;
		case UDP_SOCKET_ERROR:
		case BIND_ERROR:
		case NO_NTP_RES_ERROR:
		case TCP_SOCKET_ERROR:
		case TCP_CONNECT_ERROR:
		case BACK_OFF_FATAL_ERROR:
		default:
			current_state = &init_phy_state;
			current_state->status = EXECUTE;
			break;
	}
}