#include <atmel_start.h>
#include <avr/pgmspace.h>
#include <stdbool.h>
#include <atomic.h>
#include <timeout.h>
//#include "crypthauthlib/lib/cryptoauthlib.h"
#include "main.h"
#include "umqtt/umqtt.h"

#define STRLEN(s) (sizeof(s)/sizeof(s[0]))

/** Sockets for TCP and UDP communication */
static SOCKET tcp_client_socket = -1;
static SOCKET udp_socket = -1;

/** Wi-Fi connection state */
static volatile uint8_t wifi_connected;

const char cid[] = "projects/mchpiot-184909/locations/asia-east1/registries/my-registry/devices/my-device";

/** Variable for main loop to see if a toggle request is received */
//volatile bool toggle = false;

/** Receive buffer definition. */
static char gau8SocketTestBuffer[MAIN_WIFI_M2M_BUFFER_SIZE];

/** Buffer for wifi password */
uint8_t password[MAX_LEN];
/** Buffer for wifi SSID*/
const uint8_t ssid[] = "zambiluta";
/** Buffer for wifi security */
uint8_t security[2];
/** Variable to store status of provisioning mode  */
uint8_t provision = true;
volatile uint8_t timerSendStarted = 0, sendOpen = 0, timerConnStarted = 0;
volatile uint16_t messageCounter = 0;
volatile uint8_t timerConnTimeout = false;

static void handle_message(struct umqtt_connection __attribute__((unused))*conn, char *topic, uint8_t *data, int len) {
	// Mqtt message callback
	// Need to subscribe to a topic first	
}

const char auth_start[] PROGMEM = {0x00, 0x00, 0x00, 0xCA}; // Username length: 0x0000 = 0, password length: 0x00CA = 202

/*
MQTT TX AREA

------------------------------------------------------
| MQTT TX BUFF |            MQTT AUTH AREA            |
------------------------------------------------------
                                ^
                           MQTT_PASSWORD

MQTT AUTH AREA = 2 B (user length) + 0 B (user) + 2 B (password length) + 458 B (password) = 462B
MQTT TX BUFF = 100 B

MQTT TX AREA = 462 B + 100 B = 562 B  

MQTT PASSWORD = 458 B 
*/
// -1 accounts for null terminator that is included in the "compile time strlen", +15 is the remaining message size so that a connect msg fits exactly the whole TX buffer
#define MQTT_TX_BUFF_SIZE STRLEN(cid) - 1 + 15
#define MQTT_PASSWORD_SIZE 260
#define MQTT_AUTH_AREA_SIZE (MQTT_PASSWORD_SIZE + 4)
#define MQTT_RX_BUFF_SIZE 4

static uint8_t mqtt_tx_area[MQTT_AUTH_AREA_SIZE + MQTT_TX_BUFF_SIZE];
static uint8_t mqtt_rxbuff[MQTT_RX_BUFF_SIZE];

static uint8_t* mqtt_auth_area = mqtt_tx_area + MQTT_TX_BUFF_SIZE;
static uint8_t *mqtt_password = mqtt_tx_area + MQTT_TX_BUFF_SIZE + MQTT_AUTH_AREA_SIZE - MQTT_PASSWORD_SIZE;
bool passwordGenerated = false;

static struct umqtt_connection umqtt_conn = {
	.txbuff = {
		.start = mqtt_tx_area,
		.length = MQTT_TX_BUFF_SIZE,
	},
	
	.rxbuff = {
		.start = mqtt_rxbuff,
		.length = MQTT_RX_BUFF_SIZE,
	},
	
	.message_callback = handle_message,
};

//void wdt_init(void)
//{
    //MCUSR = 0;
    //wdt_disable();
//
    //return;
//}

/**
 * \brief Callback to get the Data from socket.
 *
 * \param[in] sock socket handler.
 * \param[in] u8Msg socket event type. Possible values are:
 *  - SOCKET_MSG_BIND
 *  - SOCKET_MSG_LISTEN
 *  - SOCKET_MSG_ACCEPT
 *  - SOCKET_MSG_CONNECT
 *  - SOCKET_MSG_RECV
 *  - SOCKET_MSG_SEND
 *  - SOCKET_MSG_SENDTO
 *  - SOCKET_MSG_RECVFROM
 * \param[in] pvMsg is a pointer to message structure. Existing types are:
 *  - tstrSocketBindMsg
 *  - tstrSocketListenMsg
 *  - tstrSocketAcceptMsg
 *  - tstrSocketConnectMsg
 *  - tstrSocketRecvMsg
 */

static uint8_t gau8SocketBuffer[MAIN_WIFI_M2M_BUFFER_SIZE];
uint32_t epoch = 0;
void m2m_tcp_socket_handler(SOCKET sock, uint8_t u8Msg, void *pvMsg)
{
	int16_t ret;
	
	switch (u8Msg) {
	case SOCKET_MSG_BIND:
	{
		/* printf("socket_cb: socket_msg_bind!\r\n"); */
		tstrSocketBindMsg *pstrBind = (tstrSocketBindMsg *)pvMsg;
		if (pstrBind && pstrBind->status == 0) {
			ret = recvfrom(sock, gau8SocketBuffer, MAIN_WIFI_M2M_BUFFER_SIZE, 0);
			if (ret != SOCK_ERR_NO_ERROR) {
				//printf("socket_cb: recv error!\r\n");
			} else {
				struct sockaddr_in addr;
				int8_t cDataBuf[48];
				int16_t ret;

				memset(cDataBuf, 0, sizeof(cDataBuf));
				cDataBuf[0] = 0x1B; /* time query */
				
				if (udp_socket >= 0) {
					/* Set NTP server socket address structure. */
					addr.sin_family = AF_INET;
					addr.sin_port = _htons(123);
					addr.sin_addr.s_addr = _htonl(0xD8EF2308); // 0xD8EF2308 time.google.com; 0xC0A80037 - alex pc on zambiluta network

					/*Send an NTP time query to the NTP server*/
					ret = sendto(udp_socket, (int8_t *)&cDataBuf, sizeof(cDataBuf), 0, (struct sockaddr *)&addr, sizeof(addr));
					if (ret != M2M_SUCCESS) {
						//printf("resolve_cb: failed to send  error!\r\n");
						return;
					}
				}
			}
		} else {
			//printf("socket_cb: bind error!\r\n");
		}

		break;
	}
	
	case SOCKET_MSG_RECVFROM:
	{
		/* printf("socket_cb: socket_msg_recvfrom!\r\n"); */
		tstrSocketRecvMsg *pstrRx = (tstrSocketRecvMsg *)pvMsg;
		if (pstrRx->pu8Buffer && pstrRx->s16BufferSize) {
			
			uint8_t packetBuffer[48];
			memcpy(packetBuffer, pstrRx->pu8Buffer, sizeof(packetBuffer));

			if ((packetBuffer[0] & 0x7) != 4) {                   /* expect only server response */
				//printf("socket_cb: Expecting response from Server Only!\r\n");
				return;                    /* MODE is not server, abort */
			} else {
				uint32_t secsSince1900 = 0;
				secsSince1900 = (uint32_t)((uint32_t)packetBuffer[40] << 24) | (uint32_t)((uint32_t)packetBuffer[41] << 16) | (uint32_t)((uint32_t)packetBuffer[42] << 8) | (uint32_t)((uint32_t)packetBuffer[43]);
			
				/* Now convert NTP time into everyday time.
				 * Unix time starts on Jan 1 1970. In seconds, that's 2208988800.
				 * Subtract seventy years.
				 */
				epoch = (secsSince1900 - 2208988800UL);
				
				//config_get_client_password(mqtt_password, MQTT_PASSWORD_SIZE, epoch);
				ret = close(sock);
				if (ret == SOCK_ERR_NO_ERROR) {
					udp_socket = -1;
				}
			}
		}
	}
	break;
	
	/* Socket connected */
	case SOCKET_MSG_CONNECT:
	{
		tstrSocketConnectMsg *pstrConnect = (tstrSocketConnectMsg *)pvMsg;
		if (pstrConnect && pstrConnect->s8Error >= 0) {
			umqtt_conn.tcp_client_socket = tcp_client_socket;
			umqtt_circ_init(&umqtt_conn.txbuff);
			umqtt_circ_init(&umqtt_conn.rxbuff);
			umqtt_init(&umqtt_conn);
			umqtt_connect_authenticated(&umqtt_conn, 120, cid);		//keep alive set to 120s
			send(tcp_client_socket, mqtt_tx_area, MQTT_TX_BUFF_SIZE + 206, 0);
			umqtt_circ_init(&umqtt_conn.txbuff);
		} else {
			close(tcp_client_socket);
			tcp_client_socket = -1;
			passwordGenerated = false;
			epoch = 0;
		}
	}
	break;

	case SOCKET_MSG_SEND:
	{
		recv(tcp_client_socket, gau8SocketTestBuffer, sizeof(gau8SocketTestBuffer), 0);
	}
	break;

	/* Message receive */
	case SOCKET_MSG_RECV:
	{
		tstrSocketRecvMsg *pstrRecv = (tstrSocketRecvMsg *)pvMsg;
			if (pstrRecv && pstrRecv->s16BufferSize > 0) {
				umqtt_circ_push(&umqtt_conn.rxbuff, pstrRecv->pu8Buffer, pstrRecv->s16BufferSize);
				umqtt_process(&umqtt_conn);
			} else {
				close(tcp_client_socket);
				tcp_client_socket = -1;
				passwordGenerated = false;
				epoch = 0;
		}
	} 
	break;
	
	default:
		break;
	}
}

/**
 * \brief Callback to get the Wi-Fi status update.
 *
 * \param[in] u8MsgType type of Wi-Fi notification. Possible types are:
 *  - [M2M_WIFI_RESP_CURRENT_RSSI](@ref M2M_WIFI_RESP_CURRENT_RSSI)
 *  - [M2M_WIFI_RESP_CON_STATE_CHANGED](@ref M2M_WIFI_RESP_CON_STATE_CHANGED)
 *  - [M2M_WIFI_RESP_CONNTION_STATE](@ref M2M_WIFI_RESP_CONNTION_STATE)
 *  - [M2M_WIFI_RESP_SCAN_DONE](@ref M2M_WIFI_RESP_SCAN_DONE)
 *  - [M2M_WIFI_RESP_SCAN_RESULT](@ref M2M_WIFI_RESP_SCAN_RESULT)
 *  - [M2M_WIFI_REQ_WPS](@ref M2M_WIFI_REQ_WPS)
 *  - [M2M_WIFI_RESP_IP_CONFIGURED](@ref M2M_WIFI_RESP_IP_CONFIGURED)
 *  - [M2M_WIFI_RESP_IP_CONFLICT](@ref M2M_WIFI_RESP_IP_CONFLICT)
 *  - [M2M_WIFI_RESP_P2P](@ref M2M_WIFI_RESP_P2P)
 *  - [M2M_WIFI_RESP_AP](@ref M2M_WIFI_RESP_AP)
 *  - [M2M_WIFI_RESP_CLIENT_INFO](@ref M2M_WIFI_RESP_CLIENT_INFO)
 * \param[in] pvMsg A pointer to a buffer containing the notification parameters
 * (if any). It should be casted to the correct data type corresponding to the
 * notification type. Existing types are:
 *  - tstrM2mWifiStateChanged
 *  - tstrM2MWPSInfo
 *  - tstrM2MP2pResp
 *  - tstrM2MAPResp
 *  - tstrM2mScanDone
 *  - tstrM2mWifiscanResult
 */
static void wifi_cb(uint8_t u8MsgType, void *pvMsg)
{
	switch (u8MsgType) {
		
	case M2M_WIFI_RESP_CON_STATE_CHANGED:
	{
		tstrM2mWifiStateChanged *pstrWifiState = (tstrM2mWifiStateChanged *)pvMsg;
		if (pstrWifiState->u8CurrState == M2M_WIFI_DISCONNECTED) {
			wifi_connected = 0;
			/* Reconnect */
			m2m_wifi_connect((char*)ssid, strlen((char*)ssid), atoi((char*)security), password, M2M_WIFI_CH_ALL);
		}
	}
	break;
	
	case M2M_WIFI_REQ_DHCP_CONF:
	{
		/* Connected and gotten IP address*/
		wifi_connected = M2M_WIFI_CONNECTED;
	}
	break;


	case M2M_WIFI_RESP_PROVISION_INFO:
	{
		tstrM2MProvisionInfo *pstrProvInfo = (tstrM2MProvisionInfo*)pvMsg;
		if (pstrProvInfo->u8Status == M2M_SUCCESS) {
			memcpy(ssid, pstrProvInfo->au8SSID, strlen((char*)(pstrProvInfo->au8SSID)));
			memcpy(password, pstrProvInfo->au8Password, strlen((char*)(pstrProvInfo->au8Password)));
			itoa(pstrProvInfo->u8SecType, (char*)security, 10);
			provision = true;
			wifi_connected = false;			
		}
	}
	

	default:
		break;
	}
}

static const char mqtt_topic[] = "/devices/my-device/events";

static absolutetime_t sendToGoogle()
{
	messageCounter = messageCounter + 1;
	if(umqtt_conn.state == UMQTT_STATE_CONNECTED) 
	{
		umqtt_publish(&umqtt_conn, mqtt_topic, &messageCounter, sizeof(messageCounter));
	}
	return 1;
}

int main(void)
{	
	struct sockaddr_in addr, addr_in;
	tstrWifiInitParam param;
	
	/** Key buffer - must match with Android app */
	uint8_t key_buf[] = KEY_BUFFER;
	
	atmel_start_init();
	//ENABLE_INTERRUPTS();
	
	volatile adc_result_t ADC_0_measurement;
	volatile uint8_t      ADC_0_measurement_normalized;

	while(1)
	{
		ADC_0_measurement = ADC_0_get_conversion(6);

		// Get 8 MSB of conversion result
		ADC_0_measurement_normalized = ADC_0_measurement >> (ADC_0_get_resolution() - 8);
		asm volatile ("nop");
	}
	
	/* Initialize the BSP. */
	nm_bsp_init();
	
	/* Callback for wifi */
	param.pfAppWifiCb = wifi_cb;
	
	/* Initialize WINC1500 Wi-Fi driver with data and status callbacks. */
	if (M2M_SUCCESS != m2m_wifi_init(&param)) {
		while (1);
	}

	memcpy(ssid, "zambiluta", sizeof("zambiluta"));
	memcpy(password, "microchip", sizeof("microchip"));
	memcpy(security, "2", sizeof("2"));

	//ioport_set_pin_high(LED_PIN);
	
	/* Initialize socket module */
	socketInit();
	registerSocketCallback(m2m_tcp_socket_handler, NULL);

	#define MAIN_WLAN_SSID                  "zambiluta" /**< Destination SSID */
	#define MAIN_WLAN_AUTH					2
	#define MAIN_WLAN_PSK                   "microchip" /**< Password for Destination SSID */

	/* Connect to router. */
	//m2m_wifi_connect((char*)ssid, strlen((char*)ssid), atoi((char*)security),(char*)password, M2M_WIFI_CH_ALL);
	m2m_wifi_connect((char *)MAIN_WLAN_SSID, sizeof(MAIN_WLAN_SSID),
			MAIN_WLAN_AUTH, (char *)MAIN_WLAN_PSK, M2M_WIFI_CH_ALL);
	
	memcpy_P(mqtt_auth_area, auth_start, 4);
	
	timer_struct_t sednToGoogle_timer = {sendToGoogle, NULL};
	Scheduler_timeout_create(&sednToGoogle_timer, 1);

	while (1) {
		/* Handle pending events from network controller. */
		m2m_wifi_handle_events(NULL);
		Scheduler_timeout_call_next_callback();
		
		if (wifi_connected == M2M_WIFI_CONNECTED) {
			
			if(epoch > 0 && passwordGenerated == false) {
				config_get_client_password(mqtt_password, MQTT_PASSWORD_SIZE, (uint32_t)epoch);
				passwordGenerated = true;
			}
			
			if (udp_socket < 0 && passwordGenerated == false) {
				udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
				if (udp_socket < 0) {
					continue;
				}

				/* Initialize default socket address structure. */
				addr_in.sin_family = AF_INET;
				addr_in.sin_addr.s_addr = _htonl(0xffffffff);
				addr_in.sin_port = _htons(6666);

				bind(udp_socket, (struct sockaddr *)&addr_in, sizeof(struct sockaddr_in));
			}
			
			if(tcp_client_socket < 0 && passwordGenerated == true) {
				//if ((tcp_client_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
				if ((tcp_client_socket = socket(AF_INET, SOCK_STREAM, 1)) < 0) {
					asm("nop");
				}

				addr.sin_family = AF_INET;
				addr.sin_port = _htons(8883); 
				addr.sin_addr.s_addr = _htonl(0x40E9B8CE); // 0x40E9B8CE - mqtt.googleapis.com, 0xC0A80036 - 0.54
				
				/* Connect server */
				sint8 ret = connect(tcp_client_socket, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

				if (ret < 0) {
					close(tcp_client_socket);
					tcp_client_socket = -1;
				}
			}
			
			
		}
	}
}