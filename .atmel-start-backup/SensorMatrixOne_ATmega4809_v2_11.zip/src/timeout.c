/**
 * \file
 *
 * \brief Timeout driver.
 *
 *
 * Copyright (C) 2016 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 *
 */

#include <stdio.h>
#include "timeout.h"
#include "atomic.h"

absolutetime_t Scheduler_dummy_handler(void *payload)
{
	return 0;
};

void Scheduler_start_timer_at_head(void);
void Scheduler_enqueue_callback(timer_struct_t *timer);
void Scheduler_set_timer_duration(absolutetime_t duration);
absolutetime_t Scheduler_make_absolute(absolutetime_t timeout);
absolutetime_t Scheduler_rebase_list(void);

timer_struct_t *Scheduler_list_head          = NULL;
timer_struct_t *Scheduler_execute_queue_head = NULL;

timer_struct_t          Scheduler_dummy                         = {Scheduler_dummy_handler};
volatile absolutetime_t Scheduler_absolute_time_of_last_timeout = 0;
volatile absolutetime_t Scheduler_last_timer_load               = 0;
volatile bool           Scheduler_is_running                    = false;

void Scheduler_timeout_init(void)
{

	while (RTC.STATUS > 0) { /* Wait for all register to be synchronized */
	}

	// RTC.CMP = 0x0; /* Compare: 0x0 */

	// RTC.CNT = 0x0; /* Counter: 0x0 */

	RTC.CTRLA = RTC_PRESCALER_DIV1_gc   /* 1 */
	            | 1 << RTC_RTCEN_bp     /* Enable: enabled */
	            | 0 << RTC_RUNSTDBY_bp; /* Run In Standby: disabled */

	// RTC.PER = 0xffff; /* Period: 0xffff */

	RTC.CLKSEL = RTC_CLKSEL_INT1K_gc; /* 32KHz divided by 32 */

	// RTC.DBGCTRL = 0 << RTC_DBGRUN_bp; /* Run in debug: disabled */

	RTC.INTCTRL = 0 << RTC_CMP_bp    /* Compare Match Interrupt enable: disabled */
	              | 1 << RTC_OVF_bp; /* Overflow Interrupt enable: enabled */

	// RTC.PITCTRLA = RTC_PERIOD_OFF_gc /* Off */
	//		 | 0 << RTC_PITEN_bp; /* Enable: disabled */

	// RTC.PITDBGCTRL = 0 << RTC_DBGRUN_bp; /* Run in debug: disabled */

	// RTC.PITINTCTRL = 0 << RTC_PI_bp; /* Periodic Interrupt: disabled */
}

void Scheduler_stop_timeouts(void)
{
	RTC.INTCTRL &= ~RTC_OVF_bm;
	Scheduler_absolute_time_of_last_timeout = 0;
	Scheduler_is_running                    = 0;
}

inline void Scheduler_set_timer_duration(absolutetime_t duration)
{
	Scheduler_last_timer_load = 65535 - duration;
	RTC.CNT                   = Scheduler_last_timer_load;
	// Wait for clock domain synchronization
	while (RTC.STATUS & RTC_CNTBUSY_bm)
		;
}

inline absolutetime_t Scheduler_make_absolute(absolutetime_t timeout)
{
	timeout += Scheduler_absolute_time_of_last_timeout;
	timeout += Scheduler_is_running ? RTC.CNT - Scheduler_last_timer_load : 0;

	return timeout;
}

inline absolutetime_t Scheduler_rebase_list(void)
{
	timer_struct_t *base_point = Scheduler_list_head;
	absolutetime_t  base       = Scheduler_list_head->absolute_time;

	while (base_point != NULL) {
		base_point->absolute_time -= base;
		base_point = base_point->next;
	}

	Scheduler_absolute_time_of_last_timeout -= base;
	return base;
}

inline void Scheduler_print_list(void)
{
	timer_struct_t *base_point = Scheduler_list_head;
	while (base_point != NULL) {
		printf("%ld -> ", (uint32_t)base_point->absolute_time);
		base_point = base_point->next;
	}
	printf("NULL\n");
}

// Returns true if the insert was at the head, false if not
bool Scheduler_sorted_insert(timer_struct_t *timer)
{
	absolutetime_t  timer_absolute_time = timer->absolute_time;
	uint8_t         at_head             = 1;
	timer_struct_t *insert_point        = Scheduler_list_head;
	timer_struct_t *prev_point          = NULL;
	timer->next                         = NULL;

	if (timer_absolute_time < Scheduler_absolute_time_of_last_timeout) {
		timer_absolute_time += 65535 - Scheduler_rebase_list() + 1;
		timer->absolute_time = timer_absolute_time;
	}

	while (insert_point != NULL) {
		if (insert_point->absolute_time > timer_absolute_time) {
			break; // found the spot
		}
		prev_point   = insert_point;
		insert_point = insert_point->next;
		at_head      = 0;
	}

	if (at_head == 1) // the front of the list.
	{
		Scheduler_set_timer_duration(65535);
		RTC.INTFLAGS = RTC_OVF_bm;

		timer->next         = (Scheduler_list_head == &Scheduler_dummy) ? Scheduler_dummy.next : Scheduler_list_head;
		Scheduler_list_head = timer;
		return true;
	} else // middle of the list
	{
		timer->next = prev_point->next;
	}
	prev_point->next = timer;
	return false;
}

void Scheduler_start_timer_at_head(void)
{
	RTC.INTCTRL &= ~RTC_OVF_bm;

	if (Scheduler_list_head == NULL) // no timeouts left
	{
		Scheduler_stop_timeouts();
		return;
	}

	absolutetime_t period = ((Scheduler_list_head != NULL) ? (Scheduler_list_head->absolute_time) : 0)
	                        - Scheduler_absolute_time_of_last_timeout;

	// Timer is too far, insert dummy and schedule timer after the dummy
	if (period > 65535) {
		Scheduler_dummy.absolute_time = Scheduler_absolute_time_of_last_timeout + 65535;
		Scheduler_dummy.next          = Scheduler_list_head;
		Scheduler_list_head           = &Scheduler_dummy;
		period                        = 65535;
	}

	Scheduler_set_timer_duration(period);

	RTC.INTCTRL |= RTC_OVF_bm;
	Scheduler_is_running = 1;
}

void Scheduler_timeout_flush_all(void)
{
	Scheduler_stop_timeouts();
	Scheduler_list_head = NULL;
}

void Scheduler_timeout_delete(timer_struct_t *timer)
{
	if (Scheduler_list_head == NULL)
		return;

	// Guard in case we get interrupted, we cannot safely compare/search and get interrupted
	RTC.INTCTRL &= ~RTC_OVF_bm;

	// Special case, the head is the one we are deleting
	if (timer == Scheduler_list_head) {
		Scheduler_list_head = Scheduler_list_head->next; // Delete the head
		Scheduler_start_timer_at_head();                 // Start the new timer at the head
	} else {                                             // More than one timer in the list, search the list.
		timer_struct_t *find_timer = Scheduler_list_head;
		timer_struct_t *prev_timer = NULL;
		while (find_timer != NULL) {
			if (find_timer == timer) {
				prev_timer->next = find_timer->next;
				break;
			}
			prev_timer = find_timer;
			find_timer = find_timer->next;
		}
		RTC.INTCTRL |= RTC_OVF_bm;
	}
}

inline void Scheduler_enqueue_callback(timer_struct_t *timer)
{
	timer_struct_t *tmp;
	timer->next = NULL;

	// Special case for empty list
	if (Scheduler_execute_queue_head == NULL) {
		Scheduler_execute_queue_head = timer;
		return;
	}

	// Find the end of the list and insert the next expired timer at the back of the queue
	tmp = Scheduler_execute_queue_head;
	while (tmp->next != NULL)
		tmp = tmp->next;

	tmp->next = timer;
}

void Scheduler_timeout_call_next_callback(void)
{

	if (Scheduler_execute_queue_head == NULL)
		return;

	// Critical section needed if Scheduler_timeout_call_next_callback()
	// was called from polling loop, and not called from ISR.
	ENTER_CRITICAL(T);
	timer_struct_t *callback_timer = Scheduler_execute_queue_head;

	// Done, remove from list
	Scheduler_execute_queue_head = Scheduler_execute_queue_head->next;

	EXIT_CRITICAL(T); // End critical section

	absolutetime_t reschedule = callback_timer->callback_ptr(callback_timer->payload);

	// Do we have to reschedule it? If yes then add delta to absolute for reschedule
	if (reschedule) {
		Scheduler_timeout_create(callback_timer, reschedule);
	}
}

void Scheduler_timeout_create(timer_struct_t *timer, absolutetime_t timeout)
{
	RTC.INTCTRL &= ~RTC_OVF_bm;

	timer->absolute_time = Scheduler_make_absolute(timeout);

	// We only have to start the timer at head if the insert was at the head
	if (Scheduler_sorted_insert(timer)) {
		Scheduler_start_timer_at_head();
	} else {
		if (Scheduler_is_running)
			RTC.INTCTRL |= RTC_OVF_bm;
	}
}

// NOTE: assumes the callback completes before the next timer tick
ISR(RTC_CNT_vect)
{
	timer_struct_t *next                    = Scheduler_list_head->next;
	Scheduler_absolute_time_of_last_timeout = Scheduler_list_head->absolute_time;
	Scheduler_last_timer_load               = 0;

	if (Scheduler_list_head != &Scheduler_dummy)
		Scheduler_enqueue_callback(Scheduler_list_head);

	// Remove expired timer for the list now (it is always the one at the head)
	Scheduler_list_head = next;

	Scheduler_start_timer_at_head();

	RTC.INTFLAGS = RTC_OVF_bm;
}

// These methods are for calculating the elapsed time in stopwatch mode.
// Scheduler_timeout_start_timer will start a
// timer with (maximum range)/2. You cannot time more than
// this and the timer will stop after this time elapses
void Scheduler_timeout_start_timer(timer_struct_t *timer)
{
	absolutetime_t i = -1;
	Scheduler_timeout_create(timer, i >> 1);
}

// This funciton stops the "stopwatch" and returns the elapsed time.
absolutetime_t Scheduler_timeout_stop_timer(timer_struct_t *timer)
{
	absolutetime_t now = Scheduler_make_absolute(0); // Do this as fast as possible for accuracy
	absolutetime_t i   = -1;
	i >>= 1;

	Scheduler_timeout_delete(timer);

	absolutetime_t diff = timer->absolute_time - now;

	// This calculates the (max range)/2 minus (remaining time) which = elapsed time
	return (i - diff);
}
