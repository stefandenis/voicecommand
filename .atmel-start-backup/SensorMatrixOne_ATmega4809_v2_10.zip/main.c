#include "main.h"
#include <atmel_start.h>
#include <avr/pgmspace.h>
#include <stdbool.h>
#include <atomic.h>
#include <timeout.h>
#include "umqtt/umqtt.h"

#define STRLEN(s) (sizeof(s)/sizeof(s[0]))

/** Sockets for TCP and UDP communication */
static SOCKET tcp_client_socket = -1;
static SOCKET udp_socket = -1;

/** Wi-Fi connection state */
static volatile uint8_t wifi_connected;

const char cid[] = "projects/mchpiot-184909/locations/asia-east1/registries/my-registry/devices/device-1";
static const char mqtt_topic[] = "/devices/device-1/events";

/** Variable for main loop to see if a toggle request is received */
//volatile bool toggle = false;

/** Receive buffer definition. */
static char gau8SocketTestBuffer[MAIN_WIFI_M2M_BUFFER_SIZE];

/** Buffer for wifi password */
uint8_t password[MAX_LEN];
/** Buffer for wifi SSID*/
const uint8_t ssid[] = "zambiluta";
/** Buffer for wifi security */
uint8_t security[2];
/** Variable to store status of provisioning mode  */
uint8_t provision = true;
volatile uint16_t messageCounter = 0;

typedef enum async_task {WAITING, SUCCESS, FAIL} async_task_t;
async_task_t promise_tls = WAITING,
		promise_ntp = WAITING,
		promise_link = WAITING,
		promise_bind = WAITING,
		promise_disconnect = WAITING,
		promise_mqtt_connect = WAITING;
static timer_struct_t sendToGoogle_timer;

static void umqtt_connected_cb (struct umqtt_connection * conn)
{
	promise_mqtt_connect = SUCCESS;
}

static void umqtt_send_packet (struct umqtt_connection *conn)
{
	send(tcp_client_socket, conn->txbuff.start, conn->txbuff.datalen, 0);
	umqtt_circ_init(&conn->txbuff);
}

const char auth_start[] PROGMEM = {0x00, 0x00, 0x00, 0xCA}; // Username length: 0x0000 = 0, password length: 0x00CA = 202

/*
MQTT TX AREA

------------------------------------------------------
| MQTT TX BUFF |            MQTT AUTH AREA            |
------------------------------------------------------
                                ^
                           MQTT_PASSWORD

MQTT AUTH AREA = 2 B (user length) + 0 B (user) + 2 B (password length) + 458 B (password) = 462B
MQTT TX BUFF = 100 B

MQTT TX AREA = 462 B + 100 B = 562 B  

MQTT PASSWORD = 458 B 
*/
// -1 accounts for null terminator that is included in the "compile time strlen", +15 is the remaining message size so that a connect msg fits exactly the whole TX buffer
#define MQTT_TX_BUFF_SIZE STRLEN(cid) - 1 + 15
#define MQTT_PASSWORD_SIZE 260
#define MQTT_AUTH_AREA_SIZE (MQTT_PASSWORD_SIZE + 4)
#define MQTT_RX_BUFF_SIZE 4

static uint8_t mqtt_tx_area[MQTT_AUTH_AREA_SIZE + MQTT_TX_BUFF_SIZE];
static uint8_t mqtt_rxbuff[MQTT_RX_BUFF_SIZE];

static uint8_t* mqtt_auth_area = mqtt_tx_area + MQTT_TX_BUFF_SIZE;
static uint8_t* mqtt_password = mqtt_tx_area + MQTT_TX_BUFF_SIZE + MQTT_AUTH_AREA_SIZE - MQTT_PASSWORD_SIZE;

static struct umqtt_connection umqtt_conn = {
	.txbuff = {
		.start = mqtt_tx_area,
		.length = MQTT_AUTH_AREA_SIZE + MQTT_TX_BUFF_SIZE,
	},
	.rxbuff = {
		.start = mqtt_rxbuff,
		.length = MQTT_RX_BUFF_SIZE,
	},
	
	.user = NULL,
	.user_len = 0,
	.password_len = 202,
	
	.clientid = cid,
	.kalive = 120,
	
	.connected_callback = umqtt_connected_cb,
	.new_packet_callback = umqtt_send_packet
};

static uint8_t gau8SocketBuffer[MAIN_WIFI_M2M_BUFFER_SIZE];
uint32_t epoch = 0;
void m2m_tcp_socket_handler(SOCKET sock, uint8_t u8Msg, void *pvMsg)
{
	int16_t ret;
	
	switch (u8Msg) {
	case SOCKET_MSG_BIND:
	{
		tstrSocketBindMsg *pstrBind = (tstrSocketBindMsg *)pvMsg;
		if (pstrBind && pstrBind->status == 0) {
			ret = recvfrom(sock, gau8SocketBuffer, MAIN_WIFI_M2M_BUFFER_SIZE, 0);
			if (ret != SOCK_ERR_NO_ERROR) {
				promise_bind = FAIL;
			} else {
				promise_bind = SUCCESS;
			}
		} else {
			promise_bind = FAIL;
		}

		break;
	}
	
	case SOCKET_MSG_RECVFROM:
	{
		/* printf("socket_cb: socket_msg_recvfrom!\r\n"); */
		tstrSocketRecvMsg *pstrRx = (tstrSocketRecvMsg *)pvMsg;
		if (pstrRx->pu8Buffer && pstrRx->s16BufferSize) {
			
			uint8_t packetBuffer[48];
			memcpy(packetBuffer, pstrRx->pu8Buffer, sizeof(packetBuffer));

			if ((packetBuffer[0] & 0x7) != 4) {                   /* expect only server response */
				//printf("socket_cb: Expecting response from Server Only!\r\n");
				return;                    /* MODE is not server, abort */
			} else {
				uint32_t secsSince1900 = 0;
				secsSince1900 = (uint32_t)((uint32_t)packetBuffer[40] << 24) | (uint32_t)((uint32_t)packetBuffer[41] << 16) | (uint32_t)((uint32_t)packetBuffer[42] << 8) | (uint32_t)((uint32_t)packetBuffer[43]);
			
				/* Now convert NTP time into everyday time.
				 * Unix time starts on Jan 1 1970. In seconds, that's 2208988800.
				 * Subtract seventy years.
				 */
				epoch = (secsSince1900 - 2208988800UL);
				promise_ntp = SUCCESS;
					
				ret = close(sock);
				if (ret == SOCK_ERR_NO_ERROR) {
					udp_socket = -1;
				}
			}
		}
	}
	break;
	
	/* Socket connected */
	case SOCKET_MSG_CONNECT:
	{
		tstrSocketConnectMsg *pstrConnect = (tstrSocketConnectMsg *)pvMsg;
		if (pstrConnect && pstrConnect->s8Error >= 0) {
			promise_tls = SUCCESS;
		} else {
			promise_tls = FAIL;
		}
	}
	break;

	case SOCKET_MSG_SEND:
	{
		recv(tcp_client_socket, gau8SocketTestBuffer, sizeof(gau8SocketTestBuffer), 0);
	}
	break;

	/* Message receive */
	case SOCKET_MSG_RECV:
	{
		tstrSocketRecvMsg *pstrRecv = (tstrSocketRecvMsg *)pvMsg;
			if (pstrRecv && pstrRecv->s16BufferSize > 0) {
				umqtt_circ_push(&umqtt_conn.rxbuff, pstrRecv->pu8Buffer, pstrRecv->s16BufferSize);
				umqtt_process(&umqtt_conn);
			} else {
				promise_disconnect = SUCCESS;
				promise_mqtt_connect = FAIL;
		}
	} 
	break;
	
	default:
		break;
	}
}

/**
 * \brief Callback to get the Wi-Fi status update.
 *
 * \param[in] u8MsgType type of Wi-Fi notification. Possible types are:
 *  - [M2M_WIFI_RESP_CURRENT_RSSI](@ref M2M_WIFI_RESP_CURRENT_RSSI)
 *  - [M2M_WIFI_RESP_CON_STATE_CHANGED](@ref M2M_WIFI_RESP_CON_STATE_CHANGED)
 *  - [M2M_WIFI_RESP_CONNTION_STATE](@ref M2M_WIFI_RESP_CONNTION_STATE)
 *  - [M2M_WIFI_RESP_SCAN_DONE](@ref M2M_WIFI_RESP_SCAN_DONE)
 *  - [M2M_WIFI_RESP_SCAN_RESULT](@ref M2M_WIFI_RESP_SCAN_RESULT)
 *  - [M2M_WIFI_REQ_WPS](@ref M2M_WIFI_REQ_WPS)
 *  - [M2M_WIFI_RESP_IP_CONFIGURED](@ref M2M_WIFI_RESP_IP_CONFIGURED)
 *  - [M2M_WIFI_RESP_IP_CONFLICT](@ref M2M_WIFI_RESP_IP_CONFLICT)
 *  - [M2M_WIFI_RESP_P2P](@ref M2M_WIFI_RESP_P2P)
 *  - [M2M_WIFI_RESP_AP](@ref M2M_WIFI_RESP_AP)
 *  - [M2M_WIFI_RESP_CLIENT_INFO](@ref M2M_WIFI_RESP_CLIENT_INFO)
 * \param[in] pvMsg A pointer to a buffer containing the notification parameters
 * (if any). It should be casted to the correct data type corresponding to the
 * notification type. Existing types are:
 *  - tstrM2mWifiStateChanged
 *  - tstrM2MWPSInfo
 *  - tstrM2MP2pResp
 *  - tstrM2MAPResp
 *  - tstrM2mScanDone
 *  - tstrM2mWifiscanResult
 */
static void wifi_cb(uint8_t u8MsgType, void *pvMsg)
{
	switch (u8MsgType) {
	
	case M2M_WIFI_REQ_DHCP_CONF:
	{
		promise_link = SUCCESS;
	}
	break;

	default:
		break;
	}
}

static absolutetime_t sendToGoogle()
{
	if(umqtt_conn.state == UMQTT_STATE_CONNECTED) 
	{
		LED0_toggle_level();
		adc_result_t ADC_0_measurement = ADC_0_get_conversion(6);
		
		messageCounter = messageCounter + 1;
		//umqtt_publish(&umqtt_conn, mqtt_topic, &messageCounter, sizeof(messageCounter));
		umqtt_publish(&umqtt_conn, mqtt_topic, &ADC_0_measurement, sizeof(ADC_0_measurement));
	}
	return 1;
}

void init(void);
void wait_init(void);
void bind_ntp_socket(void);
void wait_ntp_socket_bind(void);
void send_ntp_req(void);
void wait_ntp_res(void);
void password_generate(void);
void tls_connect();
void wait_tls_handshake(void);
void mqtt_connect(void);
void wait_mqtt_conn_ack(void);
void transmitting(void);
void retry(void);

void (*google_iot_core_app_handler)(void) = init;

void init(void) {
	tstrWifiInitParam param;
	
	/* Initialize the BSP. */
	nm_bsp_init();
	
	/* Callback for wifi */
	param.pfAppWifiCb = wifi_cb;
	
	/* Initialize WINC1500 Wi-Fi driver with data and status callbacks. */
	if (M2M_SUCCESS != m2m_wifi_init(&param)) {
		while (1);
	}

	/* Connect to router. */
	m2m_wifi_connect((char *)MAIN_WLAN_SSID, sizeof(MAIN_WLAN_SSID),
	MAIN_WLAN_AUTH, (char *)MAIN_WLAN_PSK, M2M_WIFI_CH_ALL);
	
	memcpy_P(mqtt_auth_area, auth_start, 4);
	
	promise_link = WAITING;
	google_iot_core_app_handler = wait_init;
}

void wait_init(void) {
	switch(promise_link) {
		case WAITING:
			google_iot_core_app_handler = wait_init;
			break;
		case SUCCESS:
			socketInit();
			registerSocketCallback(m2m_tcp_socket_handler, NULL);
			google_iot_core_app_handler = bind_ntp_socket;
			break;
		case FAIL:
			break;
	}
}

void bind_ntp_socket(void) {
	struct sockaddr_in addr_in;
	// Get NPT
	udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if (udp_socket < 0) {
		return;
	}

	/* Initialize default socket address structure. */
	addr_in.sin_family = AF_INET;
	addr_in.sin_addr.s_addr = _htonl(0xffffffff);
	addr_in.sin_port = _htons(6666);

	bind(udp_socket, (struct sockaddr *)&addr_in, sizeof(struct sockaddr_in));
	
	promise_bind = WAITING;
	google_iot_core_app_handler = wait_ntp_socket_bind;
}

void wait_ntp_socket_bind(void) {
	switch(promise_bind) {
		case WAITING:
			google_iot_core_app_handler = wait_ntp_socket_bind;
			break;
		case SUCCESS:
			google_iot_core_app_handler = send_ntp_req;
			break;
		case FAIL:
			break;
	}
}

void send_ntp_req(void) {
	struct sockaddr_in addr;
	int8_t cDataBuf[48];
	int16_t ret;

	memset(cDataBuf, 0, sizeof(cDataBuf));
	cDataBuf[0] = 0x1B; /* time query */
	
	addr.sin_family = AF_INET;
	addr.sin_port = _htons(123);
	addr.sin_addr.s_addr = _htonl(0xD8EF2308); // 0xD8EF2308 time.google.com; 0xC0A80037 - alex pc on zambiluta network

	/*Send an NTP time query to the NTP server*/
	ret = sendto(udp_socket, (int8_t *)&cDataBuf, sizeof(cDataBuf), 0, (struct sockaddr *)&addr, sizeof(addr));
	
	promise_ntp = WAITING;
	google_iot_core_app_handler = wait_ntp_res;
}

void wait_ntp_res(void) {
	switch(promise_ntp){
		case WAITING:
			google_iot_core_app_handler = wait_ntp_res;
			break;
		case SUCCESS:
			google_iot_core_app_handler = password_generate;
			break;
		case FAIL:
			break;
	}
}


void password_generate() {
	config_get_client_password(mqtt_password, MQTT_PASSWORD_SIZE, (uint32_t)epoch);
	umqtt_conn.password = mqtt_password;
	google_iot_core_app_handler = tls_connect;
}

void tls_connect(void) {
	struct sockaddr_in addr;

	if ((tcp_client_socket = socket(AF_INET, SOCK_STREAM, 1)) < 0) {
		return;
	}

	addr.sin_family = AF_INET;
	addr.sin_port = _htons(8883);
	addr.sin_addr.s_addr = _htonl(0x40E9B8CE); // 0x40E9B8CE - mqtt.googleapis.com, 0xC0A80036 - 0.54
		
	/* Connect server */
	sint8 ret = connect(tcp_client_socket, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

	if (ret < 0) {
		close(tcp_client_socket);
		tcp_client_socket = -1;
	}
	
	promise_tls = WAITING;
	google_iot_core_app_handler = wait_tls_handshake;
}

void wait_tls_handshake(void) {
	switch(promise_tls){
		case WAITING: 
			google_iot_core_app_handler = wait_tls_handshake;
			break;
		case SUCCESS:
			google_iot_core_app_handler = mqtt_connect;
			break;
		case FAIL:
			// TODO: Back off exponentially
			google_iot_core_app_handler = tls_connect;
	}
}

void mqtt_connect(void) {
	//umqtt_conn.tcp_client_socket = tcp_client_socket;
	umqtt_circ_init(&umqtt_conn.txbuff);
	umqtt_circ_init(&umqtt_conn.rxbuff);
		
		
		
		
	//umqtt_init(&umqtt_conn);
	umqtt_connect(&umqtt_conn);
	//umqtt_connect_authenticated(&umqtt_conn, 120, cid);		//keep alive set to 120s
	//send(tcp_client_socket, mqtt_tx_area, MQTT_TX_BUFF_SIZE + 206, 0);
	//umqtt_circ_init(&umqtt_conn.txbuff);
		
	promise_mqtt_connect = WAITING;
	google_iot_core_app_handler = wait_mqtt_conn_ack;
}

void wait_mqtt_conn_ack(void) {
	switch (promise_mqtt_connect)
	{
		case WAITING:
			google_iot_core_app_handler = wait_mqtt_conn_ack;
			break;
		case SUCCESS:
			sendToGoogle_timer.callback_ptr = sendToGoogle;
			Scheduler_timeout_create(&sendToGoogle_timer, 1);
			promise_disconnect = WAITING;
			google_iot_core_app_handler = transmitting;
			break;
		case FAIL:
			// TODO: Back off exponentially 
			break;
	} 
}

void transmitting(void) {
	switch(promise_disconnect)
	{
		case WAITING:
			Scheduler_timeout_call_next_callback();
			break;
		case SUCCESS:
			Scheduler_timeout_delete(&sendToGoogle_timer);
			google_iot_core_app_handler = retry;
			break;
	}
}

void retry(void) {
	google_iot_core_app_handler = bind_ntp_socket;
	close(tcp_client_socket);
	tcp_client_socket = -1;
}

int main(void)
{	
	atmel_start_init();
	ENABLE_INTERRUPTS();
	
	while (1) {
		m2m_wifi_handle_events(NULL);
		google_iot_core_app_handler();
	}
}